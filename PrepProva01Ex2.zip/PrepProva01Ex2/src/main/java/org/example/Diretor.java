package org.example;

public class Diretor {
    String nome;

    public Diretor(String nome) {
        this.nome = nome;
    }
}
