package org.example;

public interface FazerBarulho {

    void fazerBarulho();

}
