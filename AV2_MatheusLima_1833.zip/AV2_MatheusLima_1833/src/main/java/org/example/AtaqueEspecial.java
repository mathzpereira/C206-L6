package org.example;

public interface AtaqueEspecial {

    void ataqueEspecial();

}
