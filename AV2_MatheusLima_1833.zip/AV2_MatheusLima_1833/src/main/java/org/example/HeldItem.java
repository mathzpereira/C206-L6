package org.example;

public class HeldItem {

    // Aributo
    public String tipo;

    // Construtor
    public HeldItem(String tipo) {
        this.tipo = tipo;
    }
}
